function showView(name, button) {

    let views = document.querySelectorAll(".view");

    views.forEach(function(view) {
        view.classList.remove("active");
    });

    document.getElementById("view-" + name).classList.add("active");

    let buttons = document.querySelectorAll(".nav-button");

    buttons.forEach(function(item) {
        item.classList.remove("active");
    });

    button.classList.add("active");
}


function openModal() {

    document.getElementById("modal-new-order").hidden = false;
}


function closeModal() {

    document.getElementById("modal-new-order").hidden = true;
}


function openDrawer(card) {

    document.getElementById("drawer-id").textContent =
        card.dataset.id;

    document.getElementById("drawer-title").textContent =
        card.dataset.title;

    document.getElementById("drawer-description").textContent =
        card.dataset.desc;

    document.getElementById("drawer-solicitante").textContent =
        card.dataset.solicitante;

    document.getElementById("drawer-responsavel").textContent =
        card.dataset.responsavel;


    let statusButtons =
        document.querySelectorAll(".status-option");

    statusButtons.forEach(function(button) {

        button.classList.remove("active");

        if (button.dataset.status === card.dataset.status) {
            button.classList.add("active");
        }

    });


    document.getElementById("drawer-background").hidden = false;

    document.getElementById("drawer").hidden = false;
}


function closeDrawer() {

    document.getElementById("drawer-background").hidden = true;

    document.getElementById("drawer").hidden = true;
}


function setStatus(button) {

    let buttons =
        document.querySelectorAll(".status-option");

    buttons.forEach(function(item) {
        item.classList.remove("active");
    });

    button.classList.add("active");
}


function filterCards() {

    let search =
        document.getElementById("kanban-search").value.toLowerCase();

    let cards =
        document.querySelectorAll(".order-card");

    cards.forEach(function(card) {

        let title =
            card.dataset.title.toLowerCase();

        let id =
            card.dataset.id.toLowerCase();

        if (title.includes(search) || id.includes(search)) {
            card.style.display = "";
        } else {
            card.style.display = "none";
        }

    });
}


function toggleSwitch(button) {

    button.classList.toggle("active");
}


function saveChanges() {

    let horas =
        document.getElementById("horas").value;

    let comentario =
        document.getElementById("comentarios").value;

    alert(
        "Alterações salvas!\n\n" +
        "Horas: " + horas + "\n" +
        "Comentário: " + comentario
    );

    closeDrawer();
}


document
    .getElementById("modal-new-order")
    .addEventListener("click", function(event) {

        if (event.target === this) {
            closeModal();
        }

    });